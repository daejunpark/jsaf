var g_isItemsInit = 0;
var g_audioitem = null;
var g_videoitem = null;
var g_folderitem = null;
var g_imageitem = null;

function foundItems(){
//	alert("found");
	g_isItemsInit = 1;
}
